import express from 'express';
import multer from 'multer';
import cors from 'cors';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { existsSync, mkdirSync, readFileSync, writeFileSync, readdirSync, unlinkSync, statSync } from 'fs';
import { randomUUID } from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const PORT = 8080;
const ADMIN_KEY = 'Ms8Hr4JDl';

const DATA_DIR = join(__dirname, 'data');
const VIDEOS_DIR = join(__dirname, 'public', 'videos');
const TEAMS_FILE = join(DATA_DIR, 'teams.json');
const VIDEOS_INDEX = join(DATA_DIR, 'videos.json');

// Ensure dirs exist
[DATA_DIR, VIDEOS_DIR].forEach((d) => {
  if (!existsSync(d)) mkdirSync(d, { recursive: true });
});

// Default teams (seed if no file yet)
const DEFAULT_TEAMS = [
  {
    id: 'domino',
    name: 'домино',
    quota: 647,
    scrapOnMoon: 1598,
    deaths: 3,
    planet: 'CHALLENGE MOON',
    members: ['icelonik', 'Miles_Upsher', 'CrystalWisper', 'Ворон'],
  },
  {
    id: 'bazaru-net',
    name: 'базару нет',
    quota: 576,
    scrapOnMoon: 1598,
    deaths: 2,
    planet: 'CHALLENGE MOON',
    members: ['walters', 'Vininagibator', 'Misterpsix', 'Vector'],
  },
];

function loadTeams() {
  try {
    if (!existsSync(TEAMS_FILE)) {
      writeFileSync(TEAMS_FILE, JSON.stringify(DEFAULT_TEAMS, null, 2));
    }
    const raw = readFileSync(TEAMS_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : DEFAULT_TEAMS;
  } catch (e) {
    console.error('loadTeams error:', e);
    return DEFAULT_TEAMS;
  }
}

function saveTeams(teams) {
  writeFileSync(TEAMS_FILE, JSON.stringify(teams, null, 2));
}

function loadVideosIndex() {
  try {
    if (!existsSync(VIDEOS_INDEX)) return [];
    return JSON.parse(readFileSync(VIDEOS_INDEX, 'utf-8'));
  } catch {
    return [];
  }
}

function saveVideosIndex(arr) {
  writeFileSync(VIDEOS_INDEX, JSON.stringify(arr, null, 2));
}

// Express
const app = express();
app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Auth middleware for admin routes
function requireAdmin(req, res, next) {
  const key =
    req.headers['x-admin-key'] ||
    (req.body && req.body.key) ||
    req.query.key;
  if (key !== ADMIN_KEY) {
    return res.status(401).json({ error: 'UNAUTHORIZED' });
  }
  next();
}

// Multer for video upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, VIDEOS_DIR),
  filename: (req, file, cb) => {
    const ext = (file.originalname.split('.').pop() || 'mp4').toLowerCase();
    cb(null, `${randomUUID()}.${ext}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 500 * 1024 * 1024 }, // 500MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('video/')) cb(null, true);
    else cb(new Error('Только видео файлы'));
  },
});

// ============== Public API ==============

// Teams
app.get('/api/teams', (req, res) => {
  const teams = loadTeams().sort((a, b) => b.quota - a.quota);
  res.json(teams);
});

// Videos list (metadata only)
app.get('/api/videos', (req, res) => {
  res.json(loadVideosIndex());
});

// Serve uploaded videos
app.use('/videos', express.static(VIDEOS_DIR));

// ============== Admin API ==============

app.post('/api/auth', (req, res) => {
  const key = req.body?.key;
  if (key === ADMIN_KEY) return res.json({ ok: true });
  res.status(401).json({ error: 'WRONG_KEY' });
});

app.post('/api/teams', requireAdmin, (req, res) => {
  const teams = loadTeams();
  const { name, quota, scrapOnMoon, deaths, planet, members } = req.body;
  if (!name || typeof quota !== 'number' || !Array.isArray(members)) {
    return res.status(400).json({ error: 'INVALID_DATA' });
  }
  const team = {
    id: randomUUID(),
    name,
    quota,
    scrapOnMoon: typeof scrapOnMoon === 'number' ? scrapOnMoon : quota,
    deaths: typeof deaths === 'number' ? deaths : 0,
    planet: planet || 'CHALLENGE MOON',
    members,
  };
  teams.push(team);
  saveTeams(teams);
  res.json(team);
});

app.put('/api/teams/:id', requireAdmin, (req, res) => {
  const teams = loadTeams();
  const idx = teams.findIndex((t) => t.id === req.params.id);
  if (idx < 0) return res.status(404).json({ error: 'NOT_FOUND' });
  const { name, quota, scrapOnMoon, deaths, planet, members } = req.body;
  teams[idx] = {
    ...teams[idx],
    name: name ?? teams[idx].name,
    quota: typeof quota === 'number' ? quota : teams[idx].quota,
    scrapOnMoon: typeof scrapOnMoon === 'number' ? scrapOnMoon : teams[idx].scrapOnMoon,
    deaths: typeof deaths === 'number' ? deaths : teams[idx].deaths,
    planet: planet ?? teams[idx].planet,
    members: Array.isArray(members) ? members : teams[idx].members,
  };
  saveTeams(teams);
  res.json(teams[idx]);
});

app.delete('/api/teams/:id', requireAdmin, (req, res) => {
  let teams = loadTeams();
  const team = teams.find((t) => t.id === req.params.id);
  if (!team) return res.status(404).json({ error: 'NOT_FOUND' });
  // Also remove associated videos (metadata + file)
  const vids = loadVideosIndex();
  const remaining = [];
  for (const v of vids) {
    if (v.teamId === team.id) {
      try {
        const fp = join(VIDEOS_DIR, v.fileName);
        if (existsSync(fp)) unlinkSync(fp);
      } catch {}
    } else {
      remaining.push(v);
    }
  }
  saveVideosIndex(remaining);
  teams = teams.filter((t) => t.id !== req.params.id);
  saveTeams(teams);
  res.json({ ok: true });
});

app.post('/api/videos', requireAdmin, upload.single('video'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'NO_FILE' });
  const { nick, quota, teamId } = req.body;
  if (!nick || !quota || !teamId) {
    // cleanup
    try { unlinkSync(req.file.path); } catch {}
    return res.status(400).json({ error: 'MISSING_FIELDS' });
  }
  const teams = loadTeams();
  const team = teams.find((t) => t.id === teamId);
  if (!team) {
    try { unlinkSync(req.file.path); } catch {}
    return res.status(404).json({ error: 'TEAM_NOT_FOUND' });
  }
  const rec = {
    id: randomUUID(),
    teamId,
    teamName: team.name,
    nick,
    quota: Number(quota),
    fileName: req.file.filename,
    originalName: req.file.originalname,
    size: req.file.size,
    type: req.file.mimetype,
    createdAt: Date.now(),
  };
  const vids = loadVideosIndex();
  vids.push(rec);
  saveVideosIndex(vids);
  res.json(rec);
});

app.delete('/api/videos/:id', requireAdmin, (req, res) => {
  const vids = loadVideosIndex();
  const v = vids.find((x) => x.id === req.params.id);
  if (!v) return res.status(404).json({ error: 'NOT_FOUND' });
  try {
    const fp = join(VIDEOS_DIR, v.fileName);
    if (existsSync(fp)) unlinkSync(fp);
  } catch {}
  saveVideosIndex(vids.filter((x) => x.id !== req.params.id));
  res.json({ ok: true });
});

// ============== Static: built site ==============

const DIST_DIR = join(__dirname, 'dist');
app.use(express.static(DIST_DIR));

// Serve eshkere.html (copied to dist by vite)
app.get('/eshkere.html', (req, res) => {
  const p = join(DIST_DIR, 'eshkere.html');
  if (existsSync(p)) return res.sendFile(p);
  res.status(404).send('not found');
});

// SPA fallback
app.get('/*splat', (req, res) => {
  const p = join(DIST_DIR, 'index.html');
  if (existsSync(p)) return res.sendFile(p);
  res.status(404).send('not found');
});

app.listen(PORT, () => {
  console.log(`\n  ▌ mainjor server online`);
  console.log(`  ▌ port: ${PORT}`);
  console.log(`  ▌ site: http://localhost:${PORT}`);
  console.log(`  ▌ admin: http://localhost:${PORT}/eshkere.html`);
  console.log(`  ▌ data:  ${DATA_DIR}\n`);
});
