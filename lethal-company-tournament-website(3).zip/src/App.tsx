import { useEffect, useMemo, useState } from 'react';

type Team = {
  id: string;
  name: string;
  quota: number;
  scrapOnMoon: number;
  deaths: number;
  attemptsUsed: number;
  attemptsTotal: number;
  planet: string;
  members: string[];
};

const DEFAULT_TEAMS: Team[] = [
  {
    id: 'domino',
    name: 'домино',
    quota: 647,
    scrapOnMoon: 1598,
    deaths: 3,
    attemptsUsed: 3,
    attemptsTotal: 3,
    planet: 'CHALLENGE MOON',
    members: ['icelonik', 'Miles_Upsher', 'CrystalWisper', 'Ворон'],
  },
  {
    id: 'bazaru-net',
    name: 'базару нет',
    quota: 576,
    scrapOnMoon: 1598,
    deaths: 2,
    attemptsUsed: 3,
    attemptsTotal: 3,
    planet: 'CHALLENGE MOON',
    members: ['walters', 'Vininagibator', 'Misterpsix', 'Vector'],
  },
];

async function fetchTeams(): Promise<Team[]> {
  try {
    const r = await fetch('/api/teams', { cache: 'no-store' });
    if (!r.ok) throw new Error('bad response');
    const data = await r.json();
    if (Array.isArray(data)) return data as Team[];
    return DEFAULT_TEAMS;
  } catch {
    return DEFAULT_TEAMS;
  }
}

function Ticker({ value, duration = 1200 }: { value: number; duration?: number }) {
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(Math.round(value * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);

  return <span className="rank-num tabular-nums">{display.toLocaleString('ru-RU')}</span>;
}

function Header() {
  return (
    <header className="relative z-10 border-b border-[var(--line)]">
      <div className="max-w-[1400px] mx-auto px-6 md:px-10 py-5 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="relative w-9 h-9">
            <div className="absolute inset-0 border border-[var(--orange)] rotate-45" />
            <div className="absolute inset-1.5 bg-[var(--orange)] rotate-45" />
            <div className="absolute inset-0 flex items-center justify-center text-black font-bold text-sm">
              LC
            </div>
          </div>
          <div className="flex flex-col leading-none">
            <span className="font-mono text-[11px] text-[var(--muted)] tracking-[0.3em]">mainjor</span>
            <span className="font-mono text-[11px] text-[var(--orange)] tracking-[0.3em] mt-1">LEADERBOARD</span>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-8 font-mono text-[11px] tracking-[0.2em] text-[var(--muted)]">
          <span className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--orange)] pulse-dot" />
            SIGNAL LOCKED
          </span>
          <span>CH // 47.3</span>
          <span>LATENCY 12ms</span>
        </div>

        <div className="font-mono text-[11px] text-[var(--muted)] hidden sm:block">
          <span className="text-[var(--bone)]">RUN_</span>
          <span className="blink text-[var(--orange)]">▋</span>
        </div>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="relative z-10 max-w-[1400px] mx-auto px-6 md:px-10 pt-16 md:pt-24 pb-10">
      <div className="flex items-center gap-3 mb-6 fade-up">
        <div className="h-px flex-1 max-w-[80px] bg-gradient-to-r from-[var(--orange)] to-transparent" />
        <span className="font-mono text-[11px] tracking-[0.4em] text-[var(--orange)]">
          FILE // CLASSIFIED
        </span>
      </div>

      <h1 className="font-mono font-extrabold tracking-tight leading-[0.88] text-[var(--bone)] fade-up">
        <span
          className="glitch block text-[13vw] md:text-[9vw] lg:text-[8rem]"
          data-text="LETHAL"
        >
          LETHAL
        </span>
        <span
          className="glitch block text-[13vw] md:text-[9vw] lg:text-[8rem] text-[var(--orange)] text-glow"
          data-text="COMPANY"
          style={{ animationDelay: '0.15s' }}
        >
          COMPANY
        </span>
      </h1>

      <div className="mt-8 fade-up" style={{ animationDelay: '0.2s' }}>
        <h2 className="text-3xl md:text-5xl font-semibold text-white tracking-tight">
          Страница лидеров
        </h2>
        <p className="mt-2 font-mono text-sm md:text-base text-[var(--muted)] tracking-wide">
          Турнир по Lethal Company
        </p>
      </div>

      <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-6 fade-up" style={{ animationDelay: '0.4s' }}>
        {[
          { label: 'КОМАНД', value: '02', sub: 'ACTIVE' },
          { label: 'СКРАП', value: '1223', sub: 'TOTAL QUOTA' },
          { label: 'ЛУНА', value: 'CH.', sub: 'CHALLENGE' },
          { label: 'ПОПЫТОК', value: '06', sub: 'MAX 3/EACH' },
        ].map((s, i) => (
          <div
            key={s.label}
            className="relative border-gradient p-4 md:p-5 corner-tl corner-br"
          >
            <div className="font-mono text-[10px] tracking-[0.25em] text-[var(--muted)]">
              {s.label}
            </div>
            <div className="mt-2 text-3xl md:text-4xl font-bold text-white rank-num">
              {s.value}
            </div>
            <div className="mt-1 font-mono text-[10px] text-[var(--orange)] tracking-[0.2em]">
              {s.sub}
            </div>
            <div className="absolute top-2 right-2 font-mono text-[10px] text-[var(--muted)]">
              0{i + 1}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function TeamRow({ team, rank, expanded, onToggle }: {
  team: Team;
  rank: number;
  expanded: boolean;
  onToggle: () => void;
}) {
  const isFirst = rank === 1;

  return (
    <div
      className="slide-in relative"
      style={{ animationDelay: `${0.1 + rank * 0.12}s` }}
    >
      <button
        onClick={onToggle}
        className="row-glow relative w-full text-left border border-[var(--line)] hover:border-[var(--line-strong)] bg-[var(--ink-2)] group overflow-hidden"
      >
        <div className="sweep-line" />

        <div className="grid grid-cols-[60px_1fr_auto] md:grid-cols-[100px_1.5fr_1fr_1fr_auto] items-center gap-4 md:gap-8 px-4 md:px-8 py-5 md:py-7">
          {/* Rank */}
          <div className="relative">
            <div className={`text-4xl md:text-6xl font-black rank-num leading-none ${isFirst ? 'text-[var(--orange)] text-glow' : 'text-white/90'}`}>
              {String(rank).padStart(2, '0')}
            </div>
            <div className="mt-1 font-mono text-[9px] tracking-[0.3em] text-[var(--muted)]">
              RANK
            </div>
          </div>

          {/* Team name */}
          <div className="min-w-0">
            <div className="flex items-center gap-3">
              <div className={`w-1 h-10 md:h-14 ${isFirst ? 'bg-[var(--orange)]' : 'bg-white/40'}`} />
              <div className="min-w-0">
                <div className={`text-xl md:text-3xl font-bold tracking-tight truncate ${isFirst ? 'text-white' : 'text-white/90'}`}>
                  {team.name}
                </div>
                <div className="font-mono text-[10px] tracking-[0.25em] text-[var(--muted)] mt-1">
                  SQUAD // {team.members.length} OPS
                </div>
              </div>
            </div>
          </div>

          {/* Quota */}
          <div className="hidden md:block">
            <div className="font-mono text-[10px] tracking-[0.25em] text-[var(--muted)]">
              ИТОГ КВОТА
            </div>
            <div className={`text-2xl font-bold rank-num mt-1 ${isFirst ? 'text-[var(--orange)]' : 'text-white'}`}>
              <Ticker value={team.quota} />
            </div>
          </div>

          {/* Planet */}
          <div className="hidden md:block">
            <div className="font-mono text-[10px] tracking-[0.25em] text-[var(--muted)]">
              ПЛАНЕТА
            </div>
            <div className="text-sm font-semibold text-white mt-1.5 tracking-wide">
              {team.planet}
            </div>
          </div>

          {/* Arrow */}
          <div className={`flex items-center justify-center w-10 h-10 md:w-12 md:h-12 border border-[var(--line)] transition-all duration-300 ${expanded ? 'bg-[var(--orange)] border-[var(--orange)] rotate-180' : 'group-hover:border-[var(--orange)]'}`}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" className={expanded ? 'stroke-black' : 'stroke-white'}>
              <path d="M3 5L7 9L11 5" strokeWidth="2" strokeLinecap="square" />
            </svg>
          </div>
        </div>

        {/* Mobile row for quota & planet */}
        <div className="md:hidden grid grid-cols-2 gap-4 px-4 pb-5">
          <div>
            <div className="font-mono text-[10px] tracking-[0.25em] text-[var(--muted)]">ИТОГ КВОТА</div>
            <div className={`text-2xl font-bold rank-num mt-1 ${isFirst ? 'text-[var(--orange)]' : 'text-white'}`}>
              {team.quota.toLocaleString('ru-RU')}
            </div>
          </div>
          <div>
            <div className="font-mono text-[10px] tracking-[0.25em] text-[var(--muted)]">ПЛАНЕТА</div>
            <div className="text-sm font-semibold text-white mt-1.5 tracking-wide">{team.planet}</div>
          </div>
        </div>
      </button>

      {expanded && <TeamDetails team={team} rank={rank} />}
    </div>
  );
}

function TeamDetails({ team, rank }: { team: Team; rank: number }) {
  const quotaPercent = Math.max(1, Math.round((team.quota / Math.max(1, team.scrapOnMoon)) * 100));
  const survivalPercent = Math.max(0, Math.round(((team.members.length - team.deaths) / Math.max(1, team.members.length)) * 100));

  return (
    <div className="expand-in border border-t-0 border-[var(--line-strong)] bg-[var(--ink-3)]">
      <div className="grid md:grid-cols-2 gap-0">
        {/* Left: stats */}
        <div className="p-6 md:p-10 border-b md:border-b-0 md:border-r border-[var(--line)]">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-px bg-[var(--orange)]" />
            <span className="font-mono text-[11px] tracking-[0.3em] text-[var(--orange)]">
              ДОСЬЕ // #{String(rank).padStart(2, '0')}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <StatBlock label="ВЫНЕСЛИ СКРАПА" value={`${team.quota}`} unit="ед." accent />
            <StatBlock label="СКРАПА НА ЛУНЕ" value={`${team.scrapOnMoon}`} unit="ед." />
            <StatBlock label="ПОТЕРИ" value={`${team.deaths}`} unit={`из ${team.members.length}`} danger={team.deaths > 0} />
            <StatBlock label="ВЫЖИВШИХ" value={`${team.members.length - team.deaths}`} unit="опер." />
          </div>

          <div className="mt-8 space-y-4">
            <ProgressBar label="КВОТА / ЛУНА" percent={quotaPercent} />
            <ProgressBar label="ВЫЖИВАНИЕ" percent={survivalPercent} />
          </div>
        </div>

        {/* Right: members */}
        <div className="p-6 md:p-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-px bg-[var(--orange)]" />
            <span className="font-mono text-[11px] tracking-[0.3em] text-[var(--orange)]">
              СОСТАВ КОМАНДЫ
            </span>
          </div>

          <div className="space-y-2">
            {team.members.map((m, i) => (
              <MemberRow key={m} nick={m} index={i} />
            ))}
          </div>

          <div className="mt-8 p-4 border border-[var(--line)] bg-black/40 font-mono text-[11px] text-[var(--muted)] leading-relaxed">
            <div className="flex justify-between mb-2">
              <span className="text-[var(--orange)]">// MISSION_LOG</span>
              <span className="blink">●</span>
            </div>
            <div>PLANET: <span className="text-white">{team.planet}</span></div>
            <div>SQUAD: <span className="text-white">{team.members.length} OPS</span></div>
            <div>STATUS: <span className="text-white">COMPLETED</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}

function MemberRow({ nick, index }: { nick: string; index: number }) {
  return (
    <div className="group flex items-center justify-between p-3 border border-[var(--line)] hover:border-[var(--orange)] hover:bg-[var(--orange)]/5 transition-all">
      <div className="flex items-center gap-4">
        <div className="font-mono text-[10px] text-[var(--muted)] rank-num">
          {String(index + 1).padStart(2, '0')}
        </div>
        <div className="w-8 h-8 border border-[var(--line)] group-hover:border-[var(--orange)] flex items-center justify-center font-mono text-[10px] text-[var(--orange)] transition-colors">
          {nick.slice(0, 2).toUpperCase()}
        </div>
        <div className="font-semibold text-white tracking-wide">{nick}</div>
      </div>
      <div className="font-mono text-[10px] tracking-[0.3em] text-[var(--muted)] group-hover:text-[var(--orange)] transition-colors">
        ──
      </div>
    </div>
  );
}

function StatBlock({ label, value, unit, accent, danger }: { label: string; value: string; unit?: string; accent?: boolean; danger?: boolean }) {
  return (
    <div>
      <div className="font-mono text-[10px] tracking-[0.25em] text-[var(--muted)]">
        {label}
      </div>
      <div className="mt-2 flex items-baseline gap-2">
        <div className={`text-3xl md:text-4xl font-bold rank-num ${accent ? 'text-[var(--orange)] text-glow' : danger ? 'text-red-400' : 'text-white'}`}>
          {value}
        </div>
        {unit && <div className="font-mono text-[10px] text-[var(--muted)] tracking-[0.2em]">{unit}</div>}
      </div>
    </div>
  );
}

function ProgressBar({ label, percent }: { label: string; percent: number }) {
  return (
    <div>
      <div className="flex justify-between items-center mb-2">
        <span className="font-mono text-[10px] tracking-[0.25em] text-[var(--muted)]">{label}</span>
        <span className="font-mono text-[11px] text-[var(--orange)] rank-num">{percent}%</span>
      </div>
      <div className="h-1 bg-[var(--ink-2)] relative overflow-hidden">
        <div
          className="absolute inset-y-0 left-0 bg-gradient-to-r from-[var(--orange-3)] to-[var(--orange)]"
          style={{ width: `${percent}%`, transition: 'width 1.2s cubic-bezier(0.16, 1, 0.3, 1)' }}
        />
        <div className="absolute inset-0 bg-[repeating-linear-gradient(90deg,transparent_0_6px,rgba(0,0,0,0.4)_6px_7px)]" />
      </div>
    </div>
  );
}

function Leaderboard() {
  const [teams, setTeams] = useState<Team[]>(DEFAULT_TEAMS);
  const [expanded, setExpanded] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    const refresh = async () => {
      const current = await fetchTeams();
      if (!alive) return;
      setTeams((prev) => (JSON.stringify(prev) === JSON.stringify(current) ? prev : current));
    };
    refresh();
    const poll = setInterval(refresh, 3000);
    return () => {
      alive = false;
      clearInterval(poll);
    };
  }, []);

  const sorted = useMemo(
    () => [...teams].sort((a, b) => b.quota - a.quota),
    [teams]
  );

  return (
    <section className="relative z-10 max-w-[1400px] mx-auto px-6 md:px-10 py-10">
      <div className="flex items-end justify-between mb-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <span className="w-2 h-2 bg-[var(--orange)] pulse-dot" />
            <span className="font-mono text-[11px] tracking-[0.3em] text-[var(--orange)]">
              TOP OPERATORS
            </span>
          </div>
          <h3 className="text-2xl md:text-3xl font-semibold text-white tracking-tight">
            Лидеры
          </h3>
        </div>
        <div className="hidden md:flex items-center gap-3 font-mono text-[10px] tracking-[0.25em] text-[var(--muted)]">
          <span>SORTED BY QUOTA</span>
          <span className="w-8 h-px bg-[var(--line-strong)]" />
          <span>DESC</span>
        </div>
      </div>

      <div className="space-y-3">
        {sorted.map((t, i) => (
          <TeamRow
            key={t.id}
            team={t}
            rank={i + 1}
            expanded={expanded === t.id}
            onToggle={() => setExpanded(expanded === t.id ? null : t.id)}
          />
        ))}
      </div>
    </section>
  );
}

function Marquee() {
  const items = [
    'LETHAL COMPANY // TOURNAMENT',
    'CHALLENGE MOON ACTIVE',
    'QUOTA LOCKED',
    'SIGNAL ENCRYPTED',
    'ALL SQUADS REPORTED',
    'NO MERCY PROTOCOL',
    '[REDACTED1]',
  ];
  const row = [...items, ...items];
  return (
    <div className="relative z-10 border-y border-[var(--line)] overflow-hidden bg-[var(--ink-2)]">
      <div className="flex marquee whitespace-nowrap py-4">
        {row.map((t, i) => (
          <span key={i} className="font-mono text-[11px] tracking-[0.4em] text-[var(--muted)] px-8 flex items-center gap-8">
            <span className="w-1.5 h-1.5 bg-[var(--orange)]" />
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}

function Footer() {
  return (
    <footer className="relative z-10 border-t border-[var(--line)] mt-16">
      <div className="max-w-[1400px] mx-auto px-6 md:px-10 py-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
        <div className="space-y-3 text-[13px] md:text-[15px] leading-relaxed">
          <div>
            <span className="rainbow font-semibold">Написано</span>
            <span className="text-white font-semibold ml-2">Nector</span>
          </div>
          <div>
            <span className="rainbow font-semibold">запущено на вычислительных мощностях</span>
            <span className="text-white font-semibold ml-2">TSCE</span>
          </div>
          <div>
            <span className="red-ink font-bold text-base md:text-lg tracking-wider">эщкере</span>
          </div>
        </div>

        <div className="relative flex items-center justify-center">
          <div className="relative w-24 h-24 md:w-28 md:h-28">
            {/* outer ring */}
            <div className="absolute inset-0 border border-[var(--orange)]/40 rounded-full orbit" />
            {/* middle ring */}
            <div
              className="absolute inset-3 border border-[var(--orange)]/60 rounded-full orbit"
              style={{ animationDuration: '12s', animationDirection: 'reverse' }}
            />
            {/* inner dot */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-2 h-2 bg-[var(--orange)] rounded-full pulse-dot" />
            </div>
            {/* satellite */}
            <div className="absolute inset-0 orbit">
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-[var(--orange)] rounded-full shadow-[0_0_12px_rgba(255,106,0,0.9)]" />
            </div>
            <div
              className="absolute inset-0 orbit"
              style={{ animationDuration: '8s' }}
            >
              <div className="absolute top-1/2 -right-1 -translate-y-1/2 w-1.5 h-1.5 bg-white rounded-full shadow-[0_0_8px_rgba(255,255,255,0.8)]" />
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default function App() {
  return (
    <div className="scanlines min-h-screen relative">
      <div className="noise" />
      <div className="fixed inset-0 grid-bg pointer-events-none" />

      {/* Decorative floating elements */}
      <div className="fixed top-1/4 -left-20 w-64 h-64 rounded-full bg-[var(--orange)] opacity-[0.05] blur-[100px] pointer-events-none" />
      <div className="fixed bottom-1/4 -right-20 w-80 h-80 rounded-full bg-[var(--orange-3)] opacity-[0.08] blur-[120px] pointer-events-none" />

      <Header />
      <Hero />
      <Marquee />
      <Leaderboard />
      <Footer />
    </div>
  );
}
